-- MySQL dump 10.13  Distrib 8.2.0, for Win64 (x86_64)
--
-- Host: localhost    Database: uc4atividades
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `uc4atividades`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `uc4atividades` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `uc4atividades`;

--
-- Table structure for table `cargo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `cargo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  `salario` decimal(9,2) DEFAULT NULL,
  `comissao` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--


--
-- Table structure for table `cliente`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `cliente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cliente_usuario` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`id`, `nome`, `cpf`, `endereco`, `telefone`, `usuario_id`) VALUES (1,'Rayane Vital','28262374243','Rua Cambezes 286','64 2173 7871',NULL),(2,'Magda Mena','71899345249','Rua Vilaverde 630','65 8969 8881',NULL),(3,'Maurício Cardim','19716420795','Rua Vilaverde 1564','70 2154 5594',NULL),(4,'Mila Osório','15066534736','Rua Cavadas 428','58 8387 2498',NULL),(5,'Leo Naves','21506565310','Rua Soverosa 1446','82 6699 5665',NULL),(6,'Humberto Cabral','90676512319','Rua Veloso 1473','67 6768 1679',NULL),(7,'Poliana Portela','54011966418','Rua Fragoso 1074','75 8077 1031',NULL),(8,'Jennifer Dâmaso','80912150359','Rua Quintas 1051','71 4491 2318',NULL),(9,'Cauã Cambezes','50672260757','Rua Saraiva 326','62 6372 6038',NULL),(10,'Taynara Fiães','93881884204','Rua Robalo 971','60 4215 2902',NULL),(11,'Felipe Lima','57580851171','Rua Dinis 212','69 4913 6104',NULL),(12,'Fedra Tuna','41793671276','Rua Veloso 987','51 2465 4058',NULL),(13,'Aya Cartaxo','95095472317','Rua Grande 510','59 4345 4999',NULL),(14,'Viviana Caneira','56245489702','Rua Lagos 301','51 5640 6012',NULL),(15,'Edson Lousada','31467261734','Rua Dinis 661','67 8127 3332',NULL),(16,'Nídia Casalinho','28749240316','Rua Soverosa 163','88 6213 1886',NULL),(17,'Ibrahim Mariz','58054652402','Rua Soverosa 512','67 2978 9877',NULL),(18,'Tainara Horta','88645125273','Rua Quintas 110','89 7902 1132',NULL),(19,'Mouhamed Cidreira','46954853366','Rua Madruga 765','86 1091 2031',NULL),(20,'Alina Onofre','54227992550','Rua Faria 1007','64 1725 7633',NULL),(21,'George Melo','10101262733','Rua Ximenes 538','81 4111 9818',NULL),(22,'Zélia Macedo','39975240284','Rua Cangueiro 1014','61 6133 4281',NULL),(23,'Neusa Filipe','56087563784','Rua Caçoilo 765','50 3198 8178',NULL),(24,'Raj Espírito Santo','94988061656','Rua Sardo 150','72 9854 1381',NULL),(25,'Pérola Quinteiro','85185026407','Rua Félix 194','55 3243 8853',NULL),(26,'Stefania Chainho','54013852168','Rua Espírito Santo 389','66 1313 1696',NULL),(27,'India Adarga','18250369173','Rua Barreira 1035','67 7749 9813',NULL),(28,'Tamára Souto','76569245865','Rua Fragoso 618','83 9454 1510',NULL),(29,'Sol Medina','17647009668','Rua Cardoso 435','64 9435 5478',NULL),(30,'Sujana Homem','87673391270','Rua Soverosa 334','62 5426 1206',NULL),(31,'Virgílio Costa','71591322687','Rua Cardoso 1005','58 7480 8672',NULL),(32,'Renato Barata','58369917788','Rua Ataíde 293','59 1567 1860',NULL),(33,'Henzo Macedo','54228234557','Rua Espírito Santo 554','62 8342 4635',NULL),(34,'Iúri Santana','50031910510','Rua Rodrigues 188','53 6217 3056',NULL),(35,'Matteo Gaspar','90301594358','Rua Tedim 277','60 9605 1496',NULL),(36,'Tamar Valente','27778359919','Rua Fiães 1040','58 2836 5926',NULL),(37,'Lucília Damásio','87968162863','Rua Cambezes 292','84 4616 4343',NULL),(38,'Rayane Pedroso','71263201846','Rua Cangueiro 116','77 6569 3154',NULL),(39,'Poliana Osório','27688068352','Rua Soverosa 267','55 6615 6805',NULL),(40,'Edir Tomé','53074741949','Rua Nazário 1563','54 1362 3643',NULL),(41,'Abraão Caldas','63767971977','Rua Félix 235','74 8707 6205',NULL),(42,'Isaías Correia','64747210887','Rua Flores 435','57 8712 2902',NULL),(43,'Lídia Fialho','51185945652','Rua Viana 972','63 8340 1008',NULL),(44,'Ayra Lários','66715548277','Rua Paranhos 218','73 9119 4488',NULL),(45,'Filipe Rebocho','91403295175','Rua Palmeira 1250','64 1698 1748',NULL),(46,'Nour Félix','86877919259','Rua Flores 196','80 6948 6293',NULL),(47,'Wesley Lemes','46478486651','Rua Brião 1543','80 4901 1187',NULL),(48,'Matilde Palos','39696754912','Rua Gonçalves 1254','58 3634 9704',NULL),(49,'Nalini Caeiro','79968755245','Rua Nazário 147','88 2716 7333',NULL),(50,'Deise Leal','81287822801','Rua Robalo 1324','81 2153 6429',NULL),(51,'Eliel Marcondes','49250974267','Rua Paranhos 962','56 4713 3022',NULL),(52,'Kevin Barreto','62600667663','Rua Viana 1319','68 4299 6169',NULL),(53,'Rubim Silveira','26215406782','Rua Janes 305','81 2043 1689',NULL),(54,'Thiago Mangueira','11455017918','Rua Ribas 1312','68 8958 6518',NULL),(55,'Catarina Barreira','85084225489','Rua Palmeira 1581','62 4757 9043',NULL),(56,'Yuri Cabeça','74498188888','Rua Neiva 204','85 7680 2735',NULL),(57,'Mohamed Maranhão','58131573905','Rua Faria 828','82 2162 6506',NULL),(58,'Anny Velasco','11847123512','Rua Félix 1591','50 5738 4778',NULL),(59,'Isa Silvestre','34973975536','Rua Lagos 1126','71 6503 7750',NULL),(60,'Irene Avelar','27451331973','Rua Barreira 344','87 7125 5170',NULL),(61,'Emanuelle Pinhal','89402528822','Rua Dinis 1457','64 8953 5331',NULL),(62,'Valéria Espinosa','11286020832','Rua Vilaverde 1069','80 1010 8322',NULL),(63,'Dilnura Murtinho','97679507519','Rua Janes 539','85 5263 4951',NULL),(64,'Nicholas Morgado','45223812485','Rua Gonçalves 627','55 4984 4067',NULL),(65,'Josiane Bicalho','93169022453','Rua Vilaverde 1412','67 2334 2243',NULL),(66,'Adrián Cavaco','68963346651','Rua Cambezes 1057','75 9446 3367',NULL),(67,'Tierri Nolasco','70336122499','Rua Ribas 1259','74 9426 2976',NULL),(68,'Danilson Abelho','55398415849','Rua Rangel 187','58 1218 5416',NULL),(69,'Michelle Peixoto','43771509713','Rua Soverosa 464','67 2263 1810',NULL),(70,'Abdoulaye Flávio','47936797100','Rua Lagos 559','84 7078 3870',NULL),(71,'Elói Gabeira','86830405913','Rua Vilaverde 472','71 2582 7487',NULL),(72,'Jerónimo Narvais','98537738412','Rua Veloso 880','70 2089 4776',NULL),(73,'Rayan Capistrano','60458821507','Rua Dutra 462','54 6825 3518',NULL),(74,'Jessie Orriça','93818718583','Rua Gonçalves 402','81 2556 3238',NULL),(75,'Estefany Madruga','49948665340','Rua Tedim 1236','60 9104 6855',NULL),(76,'Emília Trigueiro','93585850293','Rua Dutra 1107','83 7928 4522',NULL),(77,'Abraão Roriz','40060603977','Rua Amarante 1501','50 7033 8746',NULL),(78,'Amina Cipriano','59319525959','Rua Dinis 1193','51 1351 9300',NULL),(79,'Maitê Orriça','43008794332','Rua Castanho 1205','50 5247 5857',NULL),(80,'Eder Serralheiro','17241037200','Rua Lagos 468','58 7919 6686',NULL),(81,'Joyce Boto','31312235105','Rua Veloso 513','85 8994 6374',NULL),(82,'Eliana Lages','60604262705','Rua Grande 1268','70 4491 9061',NULL),(83,'Nídia Macieira','38102193461','Rua Ribas 449','84 7554 6056',NULL),(84,'Fabiano Caminha','96093104787','Rua Flores 1368','61 8663 3280',NULL),(85,'Séfora Ornelas','87648382963','Rua Cambezes 1298','86 3059 3799',NULL),(86,'Leo Urias','95335821544','Rua Robalo 325','56 3924 8239',NULL),(87,'Olinda Amado','62702293801','Rua Madruga 850','53 6794 7912',NULL),(88,'Samanta Valcácer','73862068761','Rua Nazário 638','51 1628 3520',NULL),(89,'Elizabet Medina','31820000672','Rua Penha 969','51 4092 7294',NULL),(90,'Bogdan Infante','74254830620','Rua Janes 1001','56 6261 4275',NULL),(91,'Luiz Novais','91707476617','Rua Cambezes 1166','66 7816 4338',NULL),(92,'Ethan Trigueiro','98657537978','Rua Cavadas 420','58 5367 2377',NULL),(93,'Serena Alves','30230443709','Rua Penha 1391','56 1277 7350',NULL),(94,'Prince Cesário','87238787120','Rua Veloso 270','89 1943 8843',NULL),(95,'Mariano Rabelo','28084955980','Rua Brião 1487','52 4636 8214',NULL),(96,'Valter Bilhalva','24342681937','Rua Vilaverde 1055','62 9181 3315',NULL),(97,'Karolina Toscano','69414291176','Rua Caçoilo 1343','84 5915 5401',NULL),(98,'Alonso Varela','91113176586','Rua Amarante 100','72 6924 1445',NULL),(99,'Olívia Rodovalho','59687398560','Rua Sardo 733','76 5493 8056',NULL),(100,'Nathan Alencar','99791146500','Rua Carvalheira 322','53 4162 1587',NULL),(101,'Bogdan Câmara','77189575812','Rua Ximenes 1369','54 5034 2781',NULL),(102,'Amália Jordão','94418107284','Rua Carvalheira 284','72 4441 3696',NULL),(103,'Miria Bivar','49389132243','Rua Flores 858','79 7767 6464',NULL),(104,'Zaqueu Foquiço','47687965146','Rua Faria 1089','66 5257 6961',NULL),(105,'Taíssa Boga','67572581169','Rua Cambezes 1265','57 4812 2391',NULL),(106,'Eliza Salazar','77447561564','Rua Palmeira 747','58 8663 6525',NULL),(107,'Cédric Neiva','37585821380','Rua Carvalheira 240','54 5359 6039',NULL),(108,'Giovana Teodoro','35713996427','Rua Vilaverde 603','73 5122 3949',NULL),(109,'Elisa Quaresma','76560166107','Rua Neiva 1167','89 5819 3683',NULL),(110,'Dulce Regodeiro','21491463643','Rua Cavadas 645','88 2303 7193',NULL),(111,'Nicollas Pontes','67947474794','Rua Dinis 903','86 9937 2009',NULL),(112,'Sarah Ourique','76556227924','Rua Veloso 539','89 1921 4184',NULL),(113,'Benedita Silvestre','74210008134','Rua Robalo 993','88 8441 1087',NULL),(114,'Nataniel Teodoro','55631056970','Rua Espírito Santo 452','62 3841 2608',NULL),(115,'Lidiana Pacheco','73745540958','Rua Amarante 337','63 8845 6775',NULL),(116,'Destiny Modesto','63319708612','Rua Fontinha 1148','68 2938 999',NULL),(117,'Dilnura Calçada','18372924658','Rua Ataíde 1579','67 9497 4727',NULL),(118,'Edgar Valim','60902725913','Rua Lagos 1589','62 7104 2230',NULL),(119,'Steven Prates','82386468418','Rua Quintas 976','77 9399 1280',NULL),(120,'Jia Paredes','96602362852','Rua Chagas 1073','59 7408 2088',NULL),(121,'Dilnura Ávila','52227895678','Rua Brião 850','74 1087 4724',NULL),(122,'Irina Calçada','41203940370','Rua Cardoso 1424','64 7880 2283',NULL),(123,'Henzo Perdigão','14478532965','Rua Fragoso 132','57 5544 8092',NULL),(124,'Pandora Flores','29380186548','Rua Viana 1281','61 9718 2176',NULL),(125,'Bárbara Malta','80580256355','Rua Vilaverde 403','59 3638 1866',NULL),(126,'Mathilde Barrocas','33542734884','Rua Machado 1160','76 7504 5117',NULL),(127,'Pandora Carvalhais','14742726147','Rua Espírito Santo 558','56 8995 9211',NULL),(128,'Lorena Milheiriço','88696859972','Rua Passarinho 155','58 3994 3283',NULL),(129,'Álvaro Bugalho','22931034803','Rua Espírito Santo 593','51 3547 6061',NULL),(130,'Rita Cabeça','11509556920','Rua Cambezes 309','68 1415 8092',NULL),(131,'Valentin Belém','18093017705','Rua Quintas 887','81 3974 2462',NULL),(132,'Camila Quirino','50138927471','Rua Machado 269','53 2963 9187',NULL),(133,'Eliézer Taveiros','38299890738','Rua Fragoso 137','88 8581 2060',NULL),(134,'Nicolau Lobato','18078646801','Rua Caçoilo 1041','67 9054 1322',NULL),(135,'Jessé Cobra','22710282118','Rua Fragoso 1146','83 2117 8059',NULL),(136,'Marcelo Temes','36752518381','Rua Paranhos 737','50 1820 7278',NULL),(137,'Prapti Caeira','43213646308','Rua Faria 1541','52 6873 7319',NULL),(138,'Stéphanie Severo','28193479563','Rua Viana 866','58 7031 1000',NULL),(139,'Alma Prudente','90375609943','Rua Brião 613','67 2139 3741',NULL),(140,'Ariela Gaspar','45275881383','Rua Ataíde 457','53 2126 1153',NULL),(141,'Adalberto Ruas','45640664687','Rua Monjardim 1537','80 4780 7485',NULL),(142,'Dérick Rolim','59336714245','Rua Félix 662','59 4001 9450',NULL),(143,'Louise Vilhena','55515124146','Rua Neiva 1057','68 8057 4636',NULL),(144,'Crystal Cerveira','43837282653','Rua Cambezes 950','88 4535 9792',NULL),(145,'Shaira Dinis','92439130820','Rua Amarante 1556','71 7165 8254',NULL),(146,'Dario Pureza','87631796562','Rua Soverosa 778','60 3513 4102',NULL),(147,'Isabela Rebimbas','79811208307','Rua Rodrigues 389','81 4290 8975',NULL),(148,'Camilo Outeiro','33680973306','Rua Sardo 1059','63 6516 1179',NULL),(149,'Luísa Barroso','13382338565','Rua Gonçalves 1280','51 7691 6688',NULL),(150,'Rayssa Benevides','42528358949','Rua Ataíde 1172','75 2195 6787',NULL),(151,'Aicha Costa','58408188670','Rua Neiva 405','70 1532 6401',NULL),(152,'Jessica Farinha','44624555203','Rua Caçoilo 357','51 1816 6874',NULL),(153,'Stella Flores','61372225210','Rua Vilaverde 379','52 8073 8423',NULL),(154,'Darius Couceiro','99712502245','Rua Félix 434','71 7413 4727',NULL),(155,'Rosário Brito','35762931607','Rua Tedim 316','59 3186 7526',NULL),(156,'Bárbara Terra','63612587472','Rua Penha 1354','72 4776 6874',NULL),(157,'Kenny Vilaça','46235908115','Rua Monjardim 100','76 9812 8114',NULL),(158,'Nancy Basílio','83903530165','Rua Pádua 964','63 8362 5868',NULL),(159,'Louisa Jordão','52478950568','Rua Janes 1553','63 2673 1885',NULL),(160,'Matilde Moita','59594378906','Rua Ribas 1291','83 9347 9774',NULL),(161,'Aryan Valverde','73841413905','Rua Cavadas 877','64 2548 6346',NULL),(162,'Alissa Quina','22974530145','Rua Ximenes 1424','79 6611 5184',NULL),(163,'Sebastião Magalhães','54183045954','Rua Veloso 1428','66 2656 2112',NULL),(164,'Zayn Zarco','90409478509','Rua Rangel 410','59 5988 8663',NULL),(165,'Ícaro Salomão','20946415629','Rua Faria 1307','52 8338 2005',NULL),(166,'Marta Palos','26008402260','Rua Castanho 1570','75 9520 3949',NULL),(167,'Briana Pequeno','52294622782','Rua Cambezes 1019','72 6699 1540',NULL),(168,'Dominic Narvais','95197383512','Rua Saraiva 734','79 8661 8342',NULL),(169,'Nina Furtado','49627700534','Rua Quintas 298','74 7682 1201',NULL),(170,'Valentim Rabelo','51547195115','Rua Dinis 1122','82 4178 3816',NULL),(171,'Daisi Barreno','79361777559','Rua Saraiva 1268','59 8161 4810',NULL),(172,'Priscila Bogado','72657121802','Rua Sardo 1106','86 8122 2573',NULL),(173,'Rayssa Pureza','21724739367','Rua Gonçalves 562','88 3662 7637',NULL),(174,'Eli Murtinho','72577884771','Rua Cangueiro 142','58 3746 1073',NULL),(175,'Bela Póvoas','76724056107','Rua Flores 1231','61 7722 2582',NULL),(176,'Jussara Quintal','95315188102','Rua Vilaverde 859','52 4530 7696',NULL),(177,'Janilson Aleixo','73202675745','Rua Tedim 1145','88 8626 3981',NULL),(178,'Derick Xavier','74812848726','Rua Caçoilo 1365','52 6178 1677',NULL),(179,'Mariama Osório','78753874151','Rua Fiães 149','69 4735 9592',NULL),(180,'Lyana Camacho','79561164695','Rua Saraiva 1061','51 9990 2639',NULL),(181,'Cássia Canto','36450676764','Rua Dutra 1462','86 9940 9936',NULL),(182,'Marie Rolim','12603597447','Rua Vilaverde 479','68 7091 1190',NULL),(183,'Salomão Patrício','38098167602','Rua Saraiva 433','56 1904 2655',NULL),(184,'Celina Casado','95093112903','Rua Tedim 947','89 8102 9363',NULL),(185,'Martina Lima','14988824589','Rua Castanho 1460','83 2340 4835',NULL),(186,'Evelyn Picanço','96186662614','Rua Flores 330','73 1739 7614',NULL),(187,'Kennedy Macena','70402570477','Rua Lagos 149','79 9401 5145',NULL),(188,'Kristian Laureano','19348953106','Rua Ataíde 1409','85 9983 4134',NULL),(189,'Eric Caeira','86039985396','Rua Cavadas 1489','58 1572 9760',NULL),(190,'Edmundo Botelho','85794727348','Rua Cavadas 1013','71 6353 4190',NULL),(191,'Matei Caires','98838430977','Rua Dinis 984','50 5040 3468',NULL),(192,'Derick Frota','52690412723','Rua Pádua 458','84 5216 9562',NULL),(193,'Asael Maior','58384468673','Rua Ribas 1525','56 1699 2013',NULL),(194,'Stephanie Barrocas','31787305632','Rua Ximenes 666','50 7852 8459',NULL),(195,'Deivid Cabreira','22877037490','Rua Penha 415','63 1954 2050',NULL),(196,'Denise Aldeia','12864168414','Rua Carvalheira 1420','71 1665 4333',NULL),(197,'Jóni Mateus','67237737830','Rua Cambezes 622','73 1196 3740',NULL),(198,'Gina Pimentel','67471118381','Rua Vilaverde 665','70 3175 7704',NULL),(199,'Suéli Peseiro','44484365856','Rua Faria 1599','77 5007 3980',NULL),(200,'Arnaldo Caldeira','33354479197','Rua Ribas 875','64 8511 5551',NULL),(201,'Delia Janes','35894088775','Rua Dinis 1002','50 7678 6453',NULL),(202,'Francesca Teles','80214540586','Rua Ribas 735','79 5718 5539',NULL),(203,'Estefany César','20919792787','Rua Barreira 1332','84 4344 6836',NULL),(204,'Dália Paulos','55774028164','Rua Brião 1392','75 1352 4387',NULL),(205,'Aliça Antunes','73277565692','Rua Barreira 448','57 8187 4156',NULL),(206,'Nélio Guerreiro','60538443630','Rua Lagos 870','69 2249 6425',NULL),(207,'Grace Sardo','37059011263','Rua Veloso 1521','86 8439 2242',NULL),(208,'Hawa Quinta','40967594275','Rua Cambezes 847','68 8713 8011',NULL),(209,'Liam Porciúncula','71124649270','Rua Amarante 662','78 3065 1692',NULL),(210,'Alícia Leme','89354828278','Rua Neiva 928','79 2381 6037',NULL),(211,'Rodolfo Covilhã','25754099151','Rua Quintas 646','59 1409 2870',NULL),(212,'Erick Magalhães','90050664374','Rua Saraiva 1161','58 3143 4229',NULL),(213,'Denis Cesário','51685630221','Rua Amarante 1186','87 6144 8940',NULL),(214,'Mohammed Parente','46007778132','Rua Chagas 1295','86 5732 4769',NULL),(215,'Hafsa Garrido','98553298446','Rua Gonçalves 392','76 6204 2520',NULL),(216,'Élia Modesto','22430781448','Rua Chagas 445','82 6139 8106',NULL),(217,'Adonai Sardo','89632189843','Rua Félix 835','89 7461 4765',NULL),(218,'Rui Mourinho','15640485511','Rua Barreira 1275','73 7095 7973',NULL),(219,'Karolina Botelho','11908899252','Rua Veloso 585','70 8100 9148',NULL),(220,'Yaroslav Protásio','92745824566','Rua Paranhos 909','76 2708 3924',NULL),(221,'Lua Severo','77306764640','Rua Machado 295','50 1832 5636',NULL),(222,'Mayra Gusmão','42186317001','Rua das Bromélias 10','99 8598-1235',NULL),(223,'Iago Basílio','17964170090','Rua Brasil 10','99 8878-1548',NULL),(224,'Aida Madruga','27176787000','Avenida Fontes 50','99 7945-9878',NULL),(225,'Janaína Fortes','53093395070','Rua Camomila 95','99 7944-7893',NULL),(226,'Nicolau Vaz Silva','24987742039','Avenida Fontes 80','99 7944-6354',NULL),(227,'João Morgado','74488578004','Rua das Bromélias 100','99 8888-1528',NULL),(228,'Joaquim Sá Coelho','72426183047','Rua Lírios 89','99 7854-1718',NULL),(229,'Bruna Montenegro','84262948048','Rua Santos Dumont 98','99 6897-6321',NULL),(230,'Laura Muniz','67533641027','Avenida Cascata 78','99 7579-9453',NULL),(231,'José Goulart','09686683054','Rua Figueira 90','99 6897-2568',NULL),(232,'Lúcia Vargas Souza','90569215099','Rua Lírios 68','99 7789-3655',NULL);

--
-- Table structure for table `compra_item_venda`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `compra_item_venda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quantidade` int NOT NULL,
  `valor_unitario` decimal(9,2) NOT NULL,
  `subtotal` decimal(9,2) NOT NULL,
  `nome_produto` varchar(255) NOT NULL,
  `data` datetime NOT NULL,
  `data_envio` datetime NOT NULL,
  `status` varchar(45) NOT NULL,
  `valor_total` decimal(9,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra_item_venda`
--


--
-- Table structure for table `dado_cliente_dado_funcionario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dado_cliente_dado_funcionario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dado_cliente_nome` varchar(255) NOT NULL,
  `dado_cliente_cpf` varchar(11) NOT NULL,
  `dado_cliente_endereco` varchar(255) NOT NULL,
  `dado_cliente_telefone` varchar(45) NOT NULL,
  `dado_funcionario_nome` varchar(255) NOT NULL,
  `dado_funcionario_telefone` varchar(45) NOT NULL,
  `dado_funcionario_cpf` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dado_cliente_dado_funcionario`
--


--
-- Table structure for table `forma_pagamento_venda`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `forma_pagamento_venda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_pagamento` varchar(1) NOT NULL,
  `numero_cartao_pagamento` varchar(16) NOT NULL,
  `numero_parcelas_pagamento` int NOT NULL,
  `data_pagamneto` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forma_pagamento_venda`
--


--
-- Table structure for table `funcionario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `funcionario` (
  `nome` varchar(255) NOT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `cpf` varchar(11) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `cargo_id` int DEFAULT NULL,
  `usuario_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cargo_id` (`cargo_id`),
  KEY `fk_funcionario_usuario` (`usuario_id`),
  CONSTRAINT `fk_funcionario_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `funcionario_ibfk_1` FOREIGN KEY (`cargo_id`) REFERENCES `cargo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--


--
-- Table structure for table `item_venda`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `item_venda` (
  `quantidade` int NOT NULL,
  `valor_unitario` decimal(9,2) NOT NULL,
  `subtotal` decimal(9,2) NOT NULL,
  `nome_produto` varchar(255) DEFAULT NULL,
  `venda_id` int NOT NULL,
  `produto_id` int NOT NULL,
  PRIMARY KEY (`venda_id`,`produto_id`),
  KEY `venda_id` (`venda_id`),
  KEY `produto_id` (`produto_id`),
  CONSTRAINT `item_venda_ibfk_1` FOREIGN KEY (`venda_id`) REFERENCES `venda` (`id`),
  CONSTRAINT `item_venda_ibfk_2` FOREIGN KEY (`produto_id`) REFERENCES `produto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_venda`
--


--
-- Table structure for table `produto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `estoque` int DEFAULT NULL,
  `fabricante` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--


--
-- Table structure for table `usuario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `ultimo_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--


--
-- Table structure for table `venda`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `venda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` datetime DEFAULT NULL,
  `data_envio` datetime DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `valor_total` decimal(9,2) DEFAULT NULL,
  `cliente_id` int NOT NULL,
  `funcionario_id` int NOT NULL,
  `tipo_pagamento` char(1) NOT NULL,
  `numero_cartao_pagamento` varchar(16) DEFAULT NULL,
  `numero_parcelas_pagamento` int DEFAULT NULL,
  `data_pagamento` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `funcionario_id` (`funcionario_id`),
  CONSTRAINT `venda_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`),
  CONSTRAINT `venda_ibfk_2` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venda`
--


--
-- Dumping routines for database 'uc4atividades'
--
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `buscar_preco`(
    id_terreno INT
) RETURNS decimal(24,2)
    DETERMINISTIC
BEGIN
    DECLARE v_custo_m2 DECIMAL(6,2);
    DECLARE v_largura INT;
    DECLARE v_comprimento INT;

    SELECT c.custo_metro_quadrado, t.largura, t.comprimento
    INTO v_custo_m2, v_largura, v_comprimento
    FROM terrenos t
        LEFT JOIN cidades c ON c.id = t.id_cidade
    WHERE t.id = id_terreno;
    
    RETURN (v_comprimento * v_largura) * v_custo_m2;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-28 21:13:15
