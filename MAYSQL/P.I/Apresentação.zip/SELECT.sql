 DROP USER  'relatorio'@'localhost' ;
 CREATE USER 'relatorio'@'localhost' IDENTIFIED BY '123456';
 GRANT 'funcionario' TO 'relatorio'@'localhost' ;
 set default role 'relatorio' to 'funcionario'@'localhost' ;
 GRANT select on uc4atividades .* TO 'funcionario';
 SELECT * FROM mysql.user;
 SHOW GRANTS FOR 'funcionario'
 
 

