DROP USER  'venda_cliente_produto'@'localhost' ;
 CREATE USER 'venda_cliente_produto'@'localhost' IDENTIFIED BY '123456';
 GRANT 'funcionario' TO 'venda_cliente_produto'@'localhost' ;
 set default role 'venda_cliente_produto' to 'funcionario'@'localhost' ;
 GRANT SELECT, INSERT, UPDATE , DELETE on uc4atividades .* TO 'funcionario';
 SELECT * FROM mysql.user;
 SHOW GRANTS FOR 'funcionario';








